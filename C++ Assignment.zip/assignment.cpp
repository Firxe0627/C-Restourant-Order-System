#include <iomanip>
#include <istream>
#include <iostream>
#include <string>
#include <cstring>
#include <ctime>
#include <stdio.h>
#include <conio.h>
#include <cstring>
#include <cctype>
#include <cstdlib>

using namespace std;

const double taxRate = 0.06;
const double serviceCharge = 0.06;
const double discount = 0.10;

string category[ ] = {" ", "Food", "Food", "Drink", "Drink" };
string type[ ] = { " ", "Chicken Burger", "Beef Burger", "Soda", "Juice" };
double prices[ ] = {' ',6.80,6.80,2.50,2.50};

string cat[100];
string ty[100];
double total[100];
int quantity[100];

int orderNo[5] = { '0' };
double orderTotal[1] = { '0.0' };

void orderPlacement();
void menuSelection();
void menuDisplay();
void reporting();
void printInvoice(int i, double subtotal, int quan, char memberCon, char shippingCon);
void paymentProcess(double totalPayable);

int getOrder();
int getQuantity();
char getShipping();
char getMember();


void logo() {

	cout << "_     _      ______  _     _  ______ ______  _______  ______\t  " << endl;
	cout << " \\___/       |_____] |     | |_____/ | ____  |______  |_____/\t " << endl;
	cout << "_/   \\_      |_____] |_____| |    \\_ |_____| |______  |     \\_\t" << endl;

	cout << '\n';
}

void menuDisplay() {

	cout << "[     X BURGER     ]" << endl;

	cout << "-----------------------" << endl;
	cout << "- Welcome to X BURGER -" << endl;
	cout << "-----------------------" << endl;

	cout << "1.Order Menu" << endl;
	cout << "2.Reporting" << endl;
	cout << "3.Exit" << endl;

}



void menuSelection() {

	cout << setfill('-');
	cout << setw(25) << '-' << "MENU" << setw(30) << '-' << endl;
	cout << setfill(' ');
	cout << setw(2) << "No" << setw(10) << "Category" << setw(24) << "Type" << setw(18) << "Price (RM)" << endl;
	cout << setw(59) << setfill('-') << '-' << endl;
	cout << setfill(' ') << endl;

	for (int i = 1; i <5; ++i) {
		cout << fixed << setprecision(2);
		cout << i << setw(10) << category[i] << setw(24) << type[i] << setw(16) << prices[i] << endl;
		cout << endl;
	}
	cout << setw(59) << setfill('-') << '-' << endl;
}


char unit[10];
char poskod[10];
string address;
string state[] = {" ", "Selangor", "Kuala Lumpur", "Penang"};
int sta;

void orderPlacement() {

	char choice = ' ';
	double price;
	int i = 1;
	int x;
	double subtotal = 0.0;
	int quan = 0;
	char member, memberCon = 'N';
	int customer = 1;


		do {


			do {

				cout << "Order " << i << endl;

				x = getOrder();
				
				quan = getQuantity();
				
				if (quan < 1) {
					i--;
					break;
				}

				quantity[i] = quan;
				cout << endl;



				if (x >= 1 && x <= 4) {
					cat[i] = category[x];
					ty[i] = type[x];
					total[i] = double(prices[x] * quantity[i]);
					orderNo[x]+=quantity[i];

				}
				else
					cout << "Invalid choice, please try again." << endl;

			} while (x < 1 || x>4);

				do {
					cout << "Anymore order? (Y/N): ";
					cin >> choice;
					choice = toupper(choice);

					if (choice != 'Y' && choice != 'N')
						cout << "Invalid choice, please try again." << endl;

				} while (choice != 'Y' && choice != 'N');
			
		
		
			



			cout << endl;


			i += 1;
		} while (choice == 'Y');


		char shipping, shippingCon;
		int g = 1;

		memberCon = getMember();

		cout << '\n';
		
		shippingCon = getShipping();

		if (shippingCon == 'S') {
			cout << "Please enter address" << endl;
			cout << "Unit No: ";
			cin >> unit;
			cout << "Address: ";
			cin.ignore();
			getline(cin, address);
			do {
				cout << "Poscode: ";
				cin >> poskod;
				if (strlen(poskod) == 5) {
					for (g = 1; g < strlen(poskod); g++) {
						if (!isdigit(poskod[g])) {
							cout << "Please 5 digit" << endl;
							break;
						}
						else {
							break;
						}
					}

				}
				else {
					cout << "Please enter 5 digit" << endl;
				}
			} while (strlen(poskod) != 5 || !isdigit(poskod[g]));
			cout << "State: " << endl;
			for (int y = 1; y < 4; y++) {
				cout << y << '\t' << state[y] << endl;
			}
			cout << "Enter number of state: ";
			cin >> sta;

		}

		cout << '\n';


		printInvoice(i, subtotal, quantity[i], memberCon, shippingCon);
	
}

int getOrder() {
	int x;
	do {
		cout << "Enter No: ";
		cin >> x;

		if (x < 1 || x>4)
			cout << "Invalid choice, please try again." << endl;
	} while (x < 1 || x > 4);

	return x;
}

int getQuantity() {
	int quantity;
	int i = 3;

	do {
		cout << "Enter Quantity: ";

		cin >> quantity;

		if (quantity < 1) {
			i--;
			cout << "PLease enter again..." << endl;
			cout << "You still have " << i << " chance\n" << endl;
		}
	} while (quantity < 1 && i > 0);

	return quantity;
}



char getShipping() {
	char shipping;
	char shippingCon;	
	do {
		cout << "Shipping or Pick-Up (S or P): ";
		cin >> shipping;

		if (shipping == 'S' || shipping == 's') {
			shippingCon = 'S';
			return shippingCon;
		}
		else if (shipping == 'P' || shipping == 'p') {
			shippingCon = 'P';
			return shippingCon;
		}
		else {
			cout << "Invalid choice, please try again." << endl;
		}
	} while (true);
}

char getMember() {
	char member;
	char memberCon;
	char code[20];
	bool con = false;


	do {

		int f = 3;

		cout << "Member? (Y/N): ";
		cin >> member;

		switch (member) {
		case('y'):
		case('Y'):

			do {
				cout << "Enter member code: ";
				cin >> code;

				con = true;

				if (strlen(code) == 4) {
					for (int c = 1; c < strlen(code); c++) {
						if (!isdigit(code[c])) {
							cout << "Please enter number..." << endl;
							f--;
							cout << "You still have " << f << " chance.\n" << endl;
							con = false;
							break;
						}


						else if (con) {
							memberCon = 'Y';
							cout << "Valid member code." << endl;
							return memberCon;
							break;
						}
						else {
							cout << "Invalid number, please try again..." << endl;
						}
					}
				}
					
				

				else {
					cout << '\n';
					cout << "Invalid Code." << endl;
					f--;
					cout << "You still have " << f << " chance." << endl;
					cout << '\n';
					continue;
				}

			} while (f != 0);
			break;

		case('n'):
		case('N'):
			memberCon = 'N';
			return memberCon;
			break;
		default:
			cout << "Invalid Code." << endl;
		}

	} while (true);
}


void printInvoice(int i, double subtotal, int quan, char memberCon, char shippingCon) {


	int num, invoice = 1;
	double dis, tax, service, totalPayable;
	double shippingFee=5.00;

	
	cout << "Invoice: " << endl;
	cout << "\n";
	cout << setfill('*');
	cout << setw(26) << "X BURGER" << setw(19) << "*" << endl;
	cout << "Invoice No." << invoice << endl;
	cout << setfill('-');
	cout << setw(45) << "-" << endl;
	cout << setfill(' ');
	cout << setw(5) << "No. " << setw(10) << "Category" << setw(20) << "Type" << setw(10) << "Total(RM)" << endl;
	cout << setfill('-') << setw(45) << "-" << endl;
	cout << setfill(' ');

	cout << fixed << setprecision(2); 

	for (num = 1; num < i; num++) {
		cout << setw(5) << num << setw(10) << cat[num] << setw(16) << ty[num] << " * " << quantity[num] << setw(10) << total[num] << endl;
		subtotal += total[num];
		quan += quantity[num];
	}

	service = double(subtotal * serviceCharge);
	tax = double(subtotal * taxRate);
	service = round(service * 100) / 100;
    tax = round(tax * 100) / 100;
	totalPayable = double(subtotal + tax + service);

	cout << setfill('-');
	cout << "\n" << setw(45) << '-' << endl;
	cout << setfill(' ') << ' ';

	cout << "\n";
	cout << setw(40) << left << "Subtotal" << right << subtotal << endl;
	cout << setw(40) << left << "Service Charge(6%)" << '+' << right << service << endl;
	cout << setw(40) << left << "Tax(6%)" << '+' << right << tax << endl;

	if (memberCon == 'Y') {
		dis = double(subtotal * discount);
		cout << setw(40) << left << "Discount(10%)" << right << '-' << dis << endl;
		totalPayable -= double(dis);
	}

	if (shippingCon == 'S') {
		cout << setw(40) << left << "Delivery Fee: " << '+' << right << shippingFee << endl;
		totalPayable += double(shippingFee);
	}
	
	

	cout << "\n";
	cout << setw(40) << left << "Total Quantity" << right << quan << endl;
	cout << setw(40) << left << "Total Payable" << right << totalPayable << endl;

	cout << setw(45) << setfill('*') << '*' << endl;
	cout << "\n";

	orderTotal[1] += totalPayable;

	paymentProcess(totalPayable);
}

char payChoice() {
	char payment;

	do {
		cout << "Please select payment method (E-Wallet[E], Credit Card[Q], Debit Card[D], Cash[C]:";
		cin >> payment;

		if (payment != 'E' && payment != 'Q' && payment != 'D' && payment != 'C' && payment != 'e' && payment != 'q' && payment != 'd' && payment != 'c') {
			cout << "Invalid choice, please try again." << endl;
			continue;
		}
		else {
			cout << "Valid choice.\n" << endl;
			return payment;
			break;
		}



	} while (true);
}

bool check(char card[20]) {
	bool tf;

	if (strlen(card) != 16) {
		tf = false;
		return tf;
	}

	if (strlen(card) == 16) {

		for (int x = 0; x < strlen(card); x++) {
			if (isdigit(card[x]) == 0) {
				tf = false;
				return tf;
			}
		}
	}
	else {
		tf = true;
		return tf;
	}

}


void paymentProcess(double totalPayable) {

	char payment;
	double pay;
	double epay = totalPayable;
	double difference = 0.0;
	double change = 0.0;
	char card[20];
	int i = 3, x = 3;
	bool number = false;
	int mm, yy;
	char authorized[10];


	payment = payChoice();


	switch (payment) {
	case('E'):
	case('e'):
		cout << "\nPlease Scan This QR Code:\n" << endl;
		cout << "##### ### ### ### ## #####" << endl;
		cout << "# # # ######  ### ## # # #" << endl;
		cout << "##### ########### ## #####" << endl;
		cout << "       #############      " << endl;
		cout << "#########   ############  " << endl;
		cout << "#  ######## ############ #" << endl;
		cout << "       ########## ########" << endl;
		cout << "##### ##  #####  #########" << endl;
		cout << "# # # ## ######### ###   #" << endl;
		cout << "##### #  ########  #######" << endl;

		getch();

		cout << "\nPayment Received." << endl;
		cout << "Thanks for payment" << endl;

		break;

	case('Q'):
	case('D'):
	case('d'):
	case('q'):


		while (i > 0 && !number) {
			cout << "Please Enter Card Number: ";
			cin >> card;


			if (check(card)) {
				number = true;
				cout << "Valid card number." << endl;

				do{
					cout << "Please enter valid thru(MM YY): ";
					cin >> mm >> yy;
					cout << "Please enter authorized signature(3 numbers): ";
					cin >> authorized;

					if (mm <= 12 && yy > 24 && (strlen(authorized) == 3)) {
						cout << "Valid" << endl;
						number = true;
						break;
					}
					else {
						x--;
						cout << "Invalid. Please enter correct number." << endl;
						cout << "You have " << x << " chance left." << endl;
						number = false;
						continue;
					}
				} while (x > 0 && !number);
				
				break;
				
			}
			else {
				i--;
				cout << "Invalid card number. Please enter correct number." << endl;
				cout << "You have " << i << " chance left." << endl;
				continue;
			}
			
		}


		if (!number) {
			cout << "Chance run out. Pay using cash.\n" << endl;
			
			do {
				cout << "Total Payment: RM";
				cin >> pay;

				change = pay - totalPayable;

				if (pay < totalPayable) {
					difference = totalPayable - pay;
					cout << "Not enough, still missing RM" << difference << "." << endl;
				}
			} while (pay < totalPayable);

			if (pay == totalPayable) {
				cout << "Thanks for payment." << endl;
			}
			else {
				cout << "Thanks for payment." << endl;
			}

			payment = 'C';
		}
		break;

		



	case('C'):
	case('c'):

		do {
			cout << "Total Payment: RM";
			cin >> pay;

			change = pay - totalPayable;

			if (pay < totalPayable) {
				difference = totalPayable - pay;
				cout << "Not enough, still missing RM" << difference << "." << endl;
			}
		} while (pay < totalPayable);

		if (pay >= totalPayable) {
			cout << "Thanks for payment." << endl;
		}
		else {
			cout << "Thanks for payment." << endl;
		}
		break;

	default:
		cout << "Please enter again..." << endl;
	}
		
	
	cout << "\n";

		cout << setfill('*');
		cout << setw(50) << '*' << endl;
		cout << setfill(' ') << setw(19) << ' ' << "X  BURGER" << endl;
		cout << setfill('-');
		cout << setw(20) << '-' << "Receipt" << setw(23) << '-' << endl;
		cout << setfill(' ');
		cout << setw(40) << left << "Payment method: " << right;

		if (payment == 'e' || payment == 'E')
			cout << "E-Wallet" << endl;
		else if (payment == 'c' || payment == 'C')
			cout << "Cash" << endl;
		else if (payment == 'Q' || payment == 'q')
			cout << "Credit Card" << endl;
		else
			cout << "Debit Card" << endl;




		cout << setw(40) << left << "Total amount: " << right << "RM" << totalPayable << endl;

		switch (payment) {
		case('c'):
		case('C'):
			cout << setw(40) << left << "Payment amount: " << right << "RM" << pay << endl;
			break;
		case('D'):
		case('d'):
		case('q'):
		case('Q'):
		case('e'):
		case('E'):
			cout << setw(40) << left << "Payment amount: " << right << "RM" << epay << endl;
			break;
		default:
			break;
		}

		cout << setw(40) << left << "Change: " << right << "RM" << change << endl;
		cout << setfill('-') << setw(50) << '-' << endl;
		cout << setfill(' ');
}


void reporting() {
	
	int totalQuantity;
	double totalSales;

	time_t timestamp = time(NULL);
	struct tm datetime = *localtime(&timestamp);

	char date[50];

	strftime(date, 50, "%d/%m/%y", &datetime);

	cout << setfill('-') << setw(40) << '-' << endl;
	cout << setfill(' ');
	cout << left << setw(30) << "Daily Report: " << date << endl;
	cout << setfill('-') << setw(40) << '-' << endl;
	
	cout << setfill(' ');
	

	cout << "1. Chicken Burger ordered: \t" << orderNo[1] << endl;
	cout << "2. Beef Burger ordered: \t" << orderNo[2] << endl;
	cout << "3. Soda ordered: \t\t" << orderNo[3] << endl;
	cout << "4. Juice ordered: \t\t" << orderNo[4] << endl;

	cout << '\n';
	
	cout << setfill('-') << setw(40) << '-' << '\n' << endl;

	string i = "*";

	cout << "Chicken Burger: ";
	for (int x=1; x <= orderNo[1]; x++) {
		cout << i;
 	}

	cout << "\nBeef Burger: ";
	for (int x = 1; x <= orderNo[2]; x++) {
		cout << i;
	}

	cout << "\nSoda: ";
	for (int x = 1; x <= orderNo[3]; x++) {
		cout << i;
	}

	cout << "\nJuice: ";
	for (int x = 1; x <= orderNo[4]; x++) {
		cout << i;
	}
	

	cout << '\n';
	cout << setw(40) << endl;

	totalQuantity = orderNo[1] + orderNo[2] + orderNo[3] + orderNo[4];
	totalSales = orderTotal[1];
	
	cout << setfill('-') << setw(40) << '-' << endl;
	cout << "Total Quantity Sale: \t" << totalQuantity << endl;
	cout << "Total Sales: \t\tRM" << totalSales << endl;
	cout << setfill('-') << setw(40) << '-' << endl;
}
 

int main() {
	int choice1;
	int customer = 1;

	time_t timestamp = time(NULL);
	struct tm datetime = *localtime(&timestamp);

	char date[50];

	strftime(date, 50, "%d/%m/%y", &datetime);



	do {
		
		logo();

		menuDisplay();

			cout << endl << "Choice: ";
			cin >> choice1;
			cout << '\n';

		switch (choice1) {
		case(1):
			
			menuSelection();

			cout << setfill(' ');
			cout << "Customer " << customer;
			cout << setw(40) << right << date << endl;
			customer++;
			
			
			
			orderPlacement();
			cout << endl;
			break;

		case(2):
			reporting();
			cout << endl;
			break;

		case(3):
			cout << "Thank you for using X BURGER." << endl;
			break;

		default:
			cout << "Invalid choice, please try again.\n" << endl;
			break;
		}

		cout << "Press any key to clear screen." << endl;

		getch();
		system("cls");

	} while (choice1 != 3);



	return 0;
}